#include "Ypallilos apothikis.h"

void Ypallilos_apothikis::Emfanise() {
	// TODO - implement Ypallilos apothikis::Emfanise
	throw "Not yet implemented";
}

string Ypallilos_apothikis::getOnoma() {
	// TODO - implement Ypallilos apothikis::getOnoma
	throw "Not yet implemented";
}

void Ypallilos_apothikis::setOnoma(string Onoma) {
	// TODO - implement Ypallilos apothikis::setOnoma
	throw "Not yet implemented";
}

long Ypallilos_apothikis::getTilefono() {
	// TODO - implement Ypallilos apothikis::getTilefono
	throw "Not yet implemented";
}

void Ypallilos_apothikis::setTilefono(long Tilefono) {
	// TODO - implement Ypallilos apothikis::setTilefono
	throw "Not yet implemented";
}

string Ypallilos_apothikis::getEmail() {
	return this->email;
}

void Ypallilos_apothikis::setEmail(string email) {
	this->email = email;
}

Ypallilos_apothikis::Ypallilos_apothikis() {
	// TODO - implement Ypallilos apothikis::Ypallilos apothikis
	throw "Not yet implemented";
}
