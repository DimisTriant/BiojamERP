#include "Paragellia.h"

string Paragellia::Prosthese() {
	// TODO - implement Paragellia::Prosthese
	throw "Not yet implemented";
}

string Paragellia::getKodikos() {
	// TODO - implement Paragellia::getKodikos
	throw "Not yet implemented";
}

void Paragellia::setKodikos(string Kodikos) {
	// TODO - implement Paragellia::setKodikos
	throw "Not yet implemented";
}

string Paragellia::getHmerominia() {
	// TODO - implement Paragellia::getHmerominia
	throw "Not yet implemented";
}

void Paragellia::setHmerominia(string Hmerominia) {
	// TODO - implement Paragellia::setHmerominia
	throw "Not yet implemented";
}

string Paragellia::getKatastasi() {
	// TODO - implement Paragellia::getKatastasi
	throw "Not yet implemented";
}

void Paragellia::setKatastasi(string Katastasi) {
	// TODO - implement Paragellia::setKatastasi
	throw "Not yet implemented";
}

Paragellia::Paragellia() {
	// TODO - implement Paragellia::Paragellia
	throw "Not yet implemented";
}
