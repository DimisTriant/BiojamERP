#ifndef PARAGELLIA_H
#define PARAGELLIA_H

class Paragellia : Katalogos_paragellion {

private:
	Logistis Timologei;
	string Kodikos;
	string Hmerominia;
	string Katastasi;

public:
	string Prosthese();

	string getKodikos();

	void setKodikos(string Kodikos);

	string getHmerominia();

	void setHmerominia(string Hmerominia);

	string getKatastasi();

	void setKatastasi(string Katastasi);

	Paragellia();
};

#endif
