#ifndef YPALLILOS APOTHIKIS_H
#define YPALLILOS APOTHIKIS_H

class Ypallilos_apothikis {

private:
	string Onoma;
	long Tilefono;
	string email;

public:
	void Emfanise();

	string getOnoma();

	void setOnoma(string Onoma);

	long getTilefono();

	void setTilefono(long Tilefono);

	string getEmail();

	void setEmail(string email);

	Ypallilos_apothikis();
};

#endif
